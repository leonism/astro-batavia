;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ba73b128-ef05-48f5-84a1-443633094351",e._sentryDebugIdIdentifier="sentry-dbid-ba73b128-ef05-48f5-84a1-443633094351")}catch(e){}}();async function getMod() {
						return import('./web-development-trends-2024.D4z8HJOW.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
