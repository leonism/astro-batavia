;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="839e51db-9444-4bad-8403-066629ef9478",e._sentryDebugIdIdentifier="sentry-dbid-839e51db-9444-4bad-8403-066629ef9478")}catch(e){}}();async function getMod() {
						return import('./5g-technology-impact.BOdIhQZm.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
