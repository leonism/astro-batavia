;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9ed10463-3f47-4a7d-b9ee-0426563eb31b",e._sentryDebugIdIdentifier="sentry-dbid-9ed10463-3f47-4a7d-b9ee-0426563eb31b")}catch(e){}}();async function getMod() {
						return import('./cloud-computing-evolution.BVPtnH3K.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
