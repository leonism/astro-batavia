;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="17b4777f-975d-4acb-9063-a808a75b7ee6",e._sentryDebugIdIdentifier="sentry-dbid-17b4777f-975d-4acb-9063-a808a75b7ee6")}catch(e){}}();async function getMod() {
						return import('./natural-language-processing.Bhf4zsZd.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
