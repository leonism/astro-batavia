;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c13efda7-9c46-4638-963d-e223c08063e7",e._sentryDebugIdIdentifier="sentry-dbid-c13efda7-9c46-4638-963d-e223c08063e7")}catch(e){}}();async function getMod() {
						return import('./computer-vision-applications.t_HNnL7t.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
