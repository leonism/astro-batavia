;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3a5835b7-99ca-4d23-aad8-d04db6d3e467",e._sentryDebugIdIdentifier="sentry-dbid-3a5835b7-99ca-4d23-aad8-d04db6d3e467")}catch(e){}}();async function getMod() {
						return import('./augmented-reality-business.DSMu6U74.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
