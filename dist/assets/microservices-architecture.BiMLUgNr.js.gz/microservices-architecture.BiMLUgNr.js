;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2b1c7fc6-5883-4a1f-b1e8-85c3e8ae613c",e._sentryDebugIdIdentifier="sentry-dbid-2b1c7fc6-5883-4a1f-b1e8-85c3e8ae613c")}catch(e){}}();async function getMod() {
						return import('./microservices-architecture.CxxvF3KR.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
