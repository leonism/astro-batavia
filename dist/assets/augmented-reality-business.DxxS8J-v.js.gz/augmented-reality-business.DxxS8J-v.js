;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b7d0213a-7c2a-4407-b7e5-eb5e712b10db",e._sentryDebugIdIdentifier="sentry-dbid-b7d0213a-7c2a-4407-b7e5-eb5e712b10db")}catch(e){}}();async function getMod() {
						return import('./augmented-reality-business.BzLw0y2s.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
