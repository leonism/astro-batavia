;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3c73b3d0-b517-4a82-aeef-4374edd75704",e._sentryDebugIdIdentifier="sentry-dbid-3c73b3d0-b517-4a82-aeef-4374edd75704")}catch(e){}}();async function getMod() {
						return import('./robotic-process-automation.C4BAl8IB.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
