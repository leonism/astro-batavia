;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="822cd446-0b53-4b05-92b1-781a6f5b3b78",e._sentryDebugIdIdentifier="sentry-dbid-822cd446-0b53-4b05-92b1-781a6f5b3b78")}catch(e){}}();async function getMod() {
						return import('./computer-vision-applications.B3OhvSxQ.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
