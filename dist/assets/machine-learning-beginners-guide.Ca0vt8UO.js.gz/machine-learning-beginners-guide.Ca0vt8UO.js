;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="295ef449-585a-4986-995d-afaa0f3c3247",e._sentryDebugIdIdentifier="sentry-dbid-295ef449-585a-4986-995d-afaa0f3c3247")}catch(e){}}();async function getMod() {
						return import('./machine-learning-beginners-guide.DGESTB3O.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
