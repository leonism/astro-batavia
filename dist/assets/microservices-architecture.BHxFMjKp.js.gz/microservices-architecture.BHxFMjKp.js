;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e29cb8d0-e965-40ff-85f4-d0e4dbbfe236",e._sentryDebugIdIdentifier="sentry-dbid-e29cb8d0-e965-40ff-85f4-d0e4dbbfe236")}catch(e){}}();async function getMod() {
						return import('./microservices-architecture.DGHwPKNF.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
