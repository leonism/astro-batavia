;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="a0c43b01-8504-423e-882d-72a6f483bb07",e._sentryDebugIdIdentifier="sentry-dbid-a0c43b01-8504-423e-882d-72a6f483bb07")}catch(e){}}();async function getMod() {
						return import('./5g-technology-impact.-YsYu6rj.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
