;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8ac0ff6b-c059-408b-ab14-e13d0198bd2e",e._sentryDebugIdIdentifier="sentry-dbid-8ac0ff6b-c059-408b-ab14-e13d0198bd2e")}catch(e){}}();async function getMod() {
						return import('./robotic-process-automation.C-1M9xb0.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
