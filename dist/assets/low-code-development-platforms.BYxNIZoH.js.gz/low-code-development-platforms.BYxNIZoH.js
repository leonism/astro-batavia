;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e4b77d20-201e-4173-a585-73832a319908",e._sentryDebugIdIdentifier="sentry-dbid-e4b77d20-201e-4173-a585-73832a319908")}catch(e){}}();async function getMod() {
						return import('./low-code-development-platforms.D6vbbuN3.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
