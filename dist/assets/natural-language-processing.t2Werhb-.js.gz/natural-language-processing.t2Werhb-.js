;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="92edc8ea-7349-4a71-9e47-445fd3d0c705",e._sentryDebugIdIdentifier="sentry-dbid-92edc8ea-7349-4a71-9e47-445fd3d0c705")}catch(e){}}();async function getMod() {
						return import('./natural-language-processing.CGQHkY5J.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
