;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f71d2c3a-e83b-4a5e-99c3-2e7a5e76a117",e._sentryDebugIdIdentifier="sentry-dbid-f71d2c3a-e83b-4a5e-99c3-2e7a5e76a117")}catch(e){}}();async function getMod() {
						return import('./quantum-computing-basics.CeCZGDIy.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
