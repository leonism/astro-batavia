;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9d398e9a-32bf-4728-948e-bbf22d37987a",e._sentryDebugIdIdentifier="sentry-dbid-9d398e9a-32bf-4728-948e-bbf22d37987a")}catch(e){}}();async function getMod() {
						return import('./edge-computing-revolution.CJsi_thN.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
