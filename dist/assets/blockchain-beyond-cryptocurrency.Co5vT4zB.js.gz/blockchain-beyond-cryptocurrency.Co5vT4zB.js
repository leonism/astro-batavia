;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2bb771ce-a670-422d-923d-cd0c4f54826b",e._sentryDebugIdIdentifier="sentry-dbid-2bb771ce-a670-422d-923d-cd0c4f54826b")}catch(e){}}();async function getMod() {
						return import('./blockchain-beyond-cryptocurrency.DASwO9N7.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
