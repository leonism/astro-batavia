;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="625eb401-e7f7-4211-9f21-61f9e9ee0d5c",e._sentryDebugIdIdentifier="sentry-dbid-625eb401-e7f7-4211-9f21-61f9e9ee0d5c")}catch(e){}}();async function getMod() {
						return import('./iot-smart-cities.C7rmOSm6.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
