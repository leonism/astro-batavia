;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6ac31f8a-fd99-4641-933c-800e0b31cf98",e._sentryDebugIdIdentifier="sentry-dbid-6ac31f8a-fd99-4641-933c-800e0b31cf98")}catch(e){}}();async function getMod() {
						return import('./microservices-architecture.C8TxaLnU.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
