;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b82db2b0-b009-4ec8-b3af-cfd35fecb340",e._sentryDebugIdIdentifier="sentry-dbid-b82db2b0-b009-4ec8-b3af-cfd35fecb340")}catch(e){}}();async function getMod() {
						return import('./microservices-architecture.CDCblbyn.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
