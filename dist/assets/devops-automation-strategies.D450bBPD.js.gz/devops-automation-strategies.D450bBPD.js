;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="983add8e-cc8a-416b-8ce0-7b8270cb48ba",e._sentryDebugIdIdentifier="sentry-dbid-983add8e-cc8a-416b-8ce0-7b8270cb48ba")}catch(e){}}();async function getMod() {
						return import('./devops-automation-strategies.d5SNIPnB.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
