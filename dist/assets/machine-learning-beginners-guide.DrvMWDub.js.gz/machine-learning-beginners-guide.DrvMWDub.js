;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="84fef99b-de43-476c-91ef-15d85e42c266",e._sentryDebugIdIdentifier="sentry-dbid-84fef99b-de43-476c-91ef-15d85e42c266")}catch(e){}}();async function getMod() {
						return import('./machine-learning-beginners-guide.Ch5iVDkI.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
