;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8dbdc8e7-a4bc-40dc-9764-9e145568f83a",e._sentryDebugIdIdentifier="sentry-dbid-8dbdc8e7-a4bc-40dc-9764-9e145568f83a")}catch(e){}}();async function getMod() {
						return import('./iot-smart-cities.5gNuTb5r.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
