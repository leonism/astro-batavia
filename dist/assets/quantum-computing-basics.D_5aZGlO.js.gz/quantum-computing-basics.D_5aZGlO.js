;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d585a021-3bf7-471c-a79e-4a3e0b421e9f",e._sentryDebugIdIdentifier="sentry-dbid-d585a021-3bf7-471c-a79e-4a3e0b421e9f")}catch(e){}}();async function getMod() {
						return import('./quantum-computing-basics.BWs-qWIO.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
