;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6478d39a-0b77-4fab-8436-da088f6b58cb",e._sentryDebugIdIdentifier="sentry-dbid-6478d39a-0b77-4fab-8436-da088f6b58cb")}catch(e){}}();async function getMod() {
						return import('./devops-automation-strategies.C87cxm4u.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
