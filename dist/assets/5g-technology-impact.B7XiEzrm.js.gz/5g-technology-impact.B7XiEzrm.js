;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1ad04cb6-1f45-4938-9d33-eb5f23d87927",e._sentryDebugIdIdentifier="sentry-dbid-1ad04cb6-1f45-4938-9d33-eb5f23d87927")}catch(e){}}();async function getMod() {
						return import('./5g-technology-impact.DhBaI66c.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
