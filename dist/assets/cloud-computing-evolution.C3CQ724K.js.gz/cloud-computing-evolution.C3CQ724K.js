;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="4253348b-778e-4883-ae0f-06941e6a409f",e._sentryDebugIdIdentifier="sentry-dbid-4253348b-778e-4883-ae0f-06941e6a409f")}catch(e){}}();async function getMod() {
						return import('./cloud-computing-evolution.CGCPXtkZ.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
