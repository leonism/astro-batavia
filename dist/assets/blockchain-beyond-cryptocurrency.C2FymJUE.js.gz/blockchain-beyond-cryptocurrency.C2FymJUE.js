;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6638013b-3533-4315-b262-21061826430a",e._sentryDebugIdIdentifier="sentry-dbid-6638013b-3533-4315-b262-21061826430a")}catch(e){}}();async function getMod() {
						return import('./blockchain-beyond-cryptocurrency.DnxGvCL6.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
