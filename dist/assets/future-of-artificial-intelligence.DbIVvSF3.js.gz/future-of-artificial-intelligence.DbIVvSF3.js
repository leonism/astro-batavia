;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1d74078b-4b3e-4abd-b17e-f84f69fcde50",e._sentryDebugIdIdentifier="sentry-dbid-1d74078b-4b3e-4abd-b17e-f84f69fcde50")}catch(e){}}();async function getMod() {
						return import('./future-of-artificial-intelligence.BjGu1FQk.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
