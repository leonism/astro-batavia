;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="421e97aa-bb5f-4cdb-a4de-1e8133e5b99f",e._sentryDebugIdIdentifier="sentry-dbid-421e97aa-bb5f-4cdb-a4de-1e8133e5b99f")}catch(e){}}();async function getMod() {
						return import('./computer-vision-applications.FCucQBAW.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
