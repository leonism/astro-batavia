;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5dc0855a-34a9-4dea-8f17-99d35abe90d6",e._sentryDebugIdIdentifier="sentry-dbid-5dc0855a-34a9-4dea-8f17-99d35abe90d6")}catch(e){}}();async function getMod() {
						return import('./web-development-trends-2024.BH9_4n5E.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
