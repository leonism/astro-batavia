;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b6a2f531-a7cb-4735-9610-71f394265a2b",e._sentryDebugIdIdentifier="sentry-dbid-b6a2f531-a7cb-4735-9610-71f394265a2b")}catch(e){}}();async function getMod() {
						return import('./web-development-trends-2024.DMNENU1R.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
