;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="854a9ad5-f6e7-49b4-8d1f-e35c8a2197ee",e._sentryDebugIdIdentifier="sentry-dbid-854a9ad5-f6e7-49b4-8d1f-e35c8a2197ee")}catch(e){}}();async function getMod() {
						return import('./augmented-reality-business.CtKc5wYB.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
