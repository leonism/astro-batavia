;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="27134182-44a9-49ce-b6aa-389732467ea2",e._sentryDebugIdIdentifier="sentry-dbid-27134182-44a9-49ce-b6aa-389732467ea2")}catch(e){}}();async function getMod() {
						return import('./cloud-computing-evolution.CudwopOE.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
