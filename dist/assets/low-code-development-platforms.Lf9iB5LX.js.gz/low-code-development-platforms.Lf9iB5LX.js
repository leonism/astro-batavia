;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9af0ad76-ee8c-409f-97b7-eadb782c2ba9",e._sentryDebugIdIdentifier="sentry-dbid-9af0ad76-ee8c-409f-97b7-eadb782c2ba9")}catch(e){}}();async function getMod() {
						return import('./low-code-development-platforms.Dumrgg24.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
