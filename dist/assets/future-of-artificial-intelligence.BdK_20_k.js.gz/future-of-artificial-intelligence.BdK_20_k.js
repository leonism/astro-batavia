;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="78ae06c0-c07c-4ca8-8d7a-6ea651d62057",e._sentryDebugIdIdentifier="sentry-dbid-78ae06c0-c07c-4ca8-8d7a-6ea651d62057")}catch(e){}}();async function getMod() {
						return import('./future-of-artificial-intelligence.CnNP8JqK.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
