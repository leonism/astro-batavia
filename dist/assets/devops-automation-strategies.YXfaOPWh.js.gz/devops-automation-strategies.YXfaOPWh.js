;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="44874e1e-b07a-4836-88e4-15dbae717f56",e._sentryDebugIdIdentifier="sentry-dbid-44874e1e-b07a-4836-88e4-15dbae717f56")}catch(e){}}();async function getMod() {
						return import('./devops-automation-strategies.BaMa2KiT.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
