;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2342ce08-33c4-49b4-9615-08673ba57b1b",e._sentryDebugIdIdentifier="sentry-dbid-2342ce08-33c4-49b4-9615-08673ba57b1b")}catch(e){}}();async function getMod() {
						return import('./cloud-computing-evolution.BQn5aw_L.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
