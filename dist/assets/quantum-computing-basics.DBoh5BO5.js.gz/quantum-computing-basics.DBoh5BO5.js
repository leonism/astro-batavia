;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="76d81109-7d4e-418e-8ded-43f654c00562",e._sentryDebugIdIdentifier="sentry-dbid-76d81109-7d4e-418e-8ded-43f654c00562")}catch(e){}}();async function getMod() {
						return import('./quantum-computing-basics.D0E-ZTXZ.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
