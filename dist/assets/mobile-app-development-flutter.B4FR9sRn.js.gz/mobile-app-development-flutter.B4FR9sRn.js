;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="441a0a6e-c32b-4f60-bb09-b4cfeec60952",e._sentryDebugIdIdentifier="sentry-dbid-441a0a6e-c32b-4f60-bb09-b4cfeec60952")}catch(e){}}();async function getMod() {
						return import('./mobile-app-development-flutter.MVEEfHvL.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
