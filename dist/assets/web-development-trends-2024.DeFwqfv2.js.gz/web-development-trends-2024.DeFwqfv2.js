;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="49304f00-c483-45b5-a863-9ac23512c434",e._sentryDebugIdIdentifier="sentry-dbid-49304f00-c483-45b5-a863-9ac23512c434")}catch(e){}}();async function getMod() {
						return import('./web-development-trends-2024.B5cObymE.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
