;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="570e93c7-11af-4262-859b-ca2a5a9beed6",e._sentryDebugIdIdentifier="sentry-dbid-570e93c7-11af-4262-859b-ca2a5a9beed6")}catch(e){}}();async function getMod() {
						return import('./virtual-reality-applications.HQ3RCiq2.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
