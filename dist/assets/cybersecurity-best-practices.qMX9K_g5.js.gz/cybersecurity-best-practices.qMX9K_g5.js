;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1e7922fd-d1e7-40e7-9097-e413abb84b5d",e._sentryDebugIdIdentifier="sentry-dbid-1e7922fd-d1e7-40e7-9097-e413abb84b5d")}catch(e){}}();async function getMod() {
						return import('./cybersecurity-best-practices.B_2hrgvW.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
