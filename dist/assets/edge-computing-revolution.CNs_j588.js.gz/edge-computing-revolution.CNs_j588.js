;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="54f9c23d-7241-49bd-abfe-6d28ea23fa77",e._sentryDebugIdIdentifier="sentry-dbid-54f9c23d-7241-49bd-abfe-6d28ea23fa77")}catch(e){}}();async function getMod() {
						return import('./edge-computing-revolution.Cb_irN0C.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
