;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="6dae6b08-478d-4950-81f2-ca75aa680b35",e._sentryDebugIdIdentifier="sentry-dbid-6dae6b08-478d-4950-81f2-ca75aa680b35")}catch(e){}}();async function getMod() {
						return import('./low-code-development-platforms.MZZcWAtu.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
