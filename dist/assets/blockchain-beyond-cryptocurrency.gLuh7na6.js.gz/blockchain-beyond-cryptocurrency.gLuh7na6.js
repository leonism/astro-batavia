;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e18c64b1-df5a-40b8-92c0-10ec503052d1",e._sentryDebugIdIdentifier="sentry-dbid-e18c64b1-df5a-40b8-92c0-10ec503052d1")}catch(e){}}();async function getMod() {
						return import('./blockchain-beyond-cryptocurrency.wCIzFKz_.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
