;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1b8f72b9-4941-4c0b-9e4f-99ed350f588a",e._sentryDebugIdIdentifier="sentry-dbid-1b8f72b9-4941-4c0b-9e4f-99ed350f588a")}catch(e){}}();async function getMod() {
						return import('./virtual-reality-applications.BIc6nKFi.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
