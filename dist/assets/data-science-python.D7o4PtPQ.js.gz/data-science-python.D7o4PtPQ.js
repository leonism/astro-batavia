;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fce6b6a4-4e3f-4fa8-ad4b-e6be74510005",e._sentryDebugIdIdentifier="sentry-dbid-fce6b6a4-4e3f-4fa8-ad4b-e6be74510005")}catch(e){}}();async function getMod() {
						return import('./data-science-python.C2elGLxh.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
