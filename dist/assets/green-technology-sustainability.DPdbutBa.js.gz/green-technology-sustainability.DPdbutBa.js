;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="7a0f6aee-9f84-4e15-a2d2-8caff69b1585",e._sentryDebugIdIdentifier="sentry-dbid-7a0f6aee-9f84-4e15-a2d2-8caff69b1585")}catch(e){}}();async function getMod() {
						return import('./green-technology-sustainability.D8w3jo9I.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
