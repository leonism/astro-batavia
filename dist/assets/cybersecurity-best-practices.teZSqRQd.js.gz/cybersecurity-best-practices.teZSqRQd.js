;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0da04c10-34a3-4e27-96af-307044ca105e",e._sentryDebugIdIdentifier="sentry-dbid-0da04c10-34a3-4e27-96af-307044ca105e")}catch(e){}}();async function getMod() {
						return import('./cybersecurity-best-practices.D8fzA53p.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
