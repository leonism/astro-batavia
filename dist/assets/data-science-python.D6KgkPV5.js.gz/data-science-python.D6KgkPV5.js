;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="9022024e-9aa7-45d8-9059-5cbdb3d11dcf",e._sentryDebugIdIdentifier="sentry-dbid-9022024e-9aa7-45d8-9059-5cbdb3d11dcf")}catch(e){}}();async function getMod() {
						return import('./data-science-python.yfkerq7Y.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
