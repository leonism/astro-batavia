;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c1f7b2ba-775a-40f5-b83c-9a2f144f1f6a",e._sentryDebugIdIdentifier="sentry-dbid-c1f7b2ba-775a-40f5-b83c-9a2f144f1f6a")}catch(e){}}();async function getMod() {
						return import('./data-science-python.BEDThL6h.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
