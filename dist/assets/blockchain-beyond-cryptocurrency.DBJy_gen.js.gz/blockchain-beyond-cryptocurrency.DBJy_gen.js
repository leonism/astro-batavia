;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="647f3c00-c1bc-4455-8186-19ddfd8451b3",e._sentryDebugIdIdentifier="sentry-dbid-647f3c00-c1bc-4455-8186-19ddfd8451b3")}catch(e){}}();async function getMod() {
						return import('./blockchain-beyond-cryptocurrency.COl7JYll.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
