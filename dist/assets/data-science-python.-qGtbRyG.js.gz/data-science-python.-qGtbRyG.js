;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="a476b4ca-b169-46b4-bd4c-c149d74e95cc",e._sentryDebugIdIdentifier="sentry-dbid-a476b4ca-b169-46b4-bd4c-c149d74e95cc")}catch(e){}}();async function getMod() {
						return import('./data-science-python.CZdGJJZc.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
