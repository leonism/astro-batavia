;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="45f43823-d20e-422c-9bf7-9126ea3ad2de",e._sentryDebugIdIdentifier="sentry-dbid-45f43823-d20e-422c-9bf7-9126ea3ad2de")}catch(e){}}();async function getMod() {
						return import('./robotic-process-automation.ieaNQ1dA.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
