;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="408c4197-fe3b-435b-ab38-8806a2cc861a",e._sentryDebugIdIdentifier="sentry-dbid-408c4197-fe3b-435b-ab38-8806a2cc861a")}catch(e){}}();async function getMod() {
						return import('./virtual-reality-applications.mMWb7pRX.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
