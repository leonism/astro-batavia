;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1c808f3b-6160-4f71-b544-9a2afc710e62",e._sentryDebugIdIdentifier="sentry-dbid-1c808f3b-6160-4f71-b544-9a2afc710e62")}catch(e){}}();async function getMod() {
						return import('./future-of-artificial-intelligence.BPrC8yO1.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
