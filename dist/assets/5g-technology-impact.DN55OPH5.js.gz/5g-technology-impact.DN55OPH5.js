;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0075b83f-b39a-41dd-a34e-3299ece3b6fd",e._sentryDebugIdIdentifier="sentry-dbid-0075b83f-b39a-41dd-a34e-3299ece3b6fd")}catch(e){}}();async function getMod() {
						return import('./5g-technology-impact.Cyk7jRn8.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
