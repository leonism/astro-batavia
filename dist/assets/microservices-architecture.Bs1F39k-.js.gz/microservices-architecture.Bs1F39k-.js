;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5ac61d0c-254a-42c2-940e-8b962b259dc1",e._sentryDebugIdIdentifier="sentry-dbid-5ac61d0c-254a-42c2-940e-8b962b259dc1")}catch(e){}}();async function getMod() {
						return import('./microservices-architecture.Yfx-no1e.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
