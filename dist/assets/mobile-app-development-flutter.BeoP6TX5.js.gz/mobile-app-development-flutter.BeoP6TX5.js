;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="302be83d-0ec8-43f7-ad14-eea85eb5b43f",e._sentryDebugIdIdentifier="sentry-dbid-302be83d-0ec8-43f7-ad14-eea85eb5b43f")}catch(e){}}();async function getMod() {
						return import('./mobile-app-development-flutter.rpcBfO8w.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
