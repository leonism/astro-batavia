;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="144b12ad-5ac7-4269-9fc1-bab9cfc5a98e",e._sentryDebugIdIdentifier="sentry-dbid-144b12ad-5ac7-4269-9fc1-bab9cfc5a98e")}catch(e){}}();async function getMod() {
						return import('./machine-learning-beginners-guide.DO0Fr0dh.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
