;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c74437e4-5e31-487e-b405-36d6c6f0573c",e._sentryDebugIdIdentifier="sentry-dbid-c74437e4-5e31-487e-b405-36d6c6f0573c")}catch(e){}}();async function getMod() {
						return import('./natural-language-processing.tvhRsdfK.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
