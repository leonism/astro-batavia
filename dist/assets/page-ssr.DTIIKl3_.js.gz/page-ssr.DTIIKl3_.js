;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="92c735fe-57aa-43eb-8de9-fa3c599fba2d",e._sentryDebugIdIdentifier="sentry-dbid-92c735fe-57aa-43eb-8de9-fa3c599fba2d")}catch(e){}}();import * as Sentry from '@sentry/astro';
import './_sentry-release-injection-file.9EBHH7D5.js';

Sentry.init({
  dsn: undefined                                 ,
  debug: false,
  environment: undefined                                 ,
  release: undefined                                            ,
  tracesSampleRate: 1
});
