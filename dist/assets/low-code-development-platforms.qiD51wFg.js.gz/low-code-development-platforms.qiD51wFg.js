;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fc22186a-7660-443f-a86e-d52f4f43ffed",e._sentryDebugIdIdentifier="sentry-dbid-fc22186a-7660-443f-a86e-d52f4f43ffed")}catch(e){}}();async function getMod() {
						return import('./low-code-development-platforms.CEUWT-hq.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
