;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e5409bf7-116e-4d1d-92e4-4d6573499820",e._sentryDebugIdIdentifier="sentry-dbid-e5409bf7-116e-4d1d-92e4-4d6573499820")}catch(e){}}();async function getMod() {
						return import('./cloud-computing-evolution.BqMkCvLK.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
