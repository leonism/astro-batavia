;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ebeb9f65-5728-4b50-9665-b1fdce61f6c0",e._sentryDebugIdIdentifier="sentry-dbid-ebeb9f65-5728-4b50-9665-b1fdce61f6c0")}catch(e){}}();async function getMod() {
						return import('./augmented-reality-business.KzjR3NiI.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
