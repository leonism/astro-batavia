;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="b5154610-1369-47d7-be3e-1fbae0d73f29",e._sentryDebugIdIdentifier="sentry-dbid-b5154610-1369-47d7-be3e-1fbae0d73f29")}catch(e){}}();async function getMod() {
						return import('./virtual-reality-applications.CNhAaUHT.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
