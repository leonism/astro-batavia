;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fb6c07c0-6d12-4f2a-8ae9-4e04933c68ae",e._sentryDebugIdIdentifier="sentry-dbid-fb6c07c0-6d12-4f2a-8ae9-4e04933c68ae")}catch(e){}}();async function getMod() {
						return import('./edge-computing-revolution.CsUA0g2N.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
