;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8dc80c4c-c839-4c5e-b624-d67c4ba75bc0",e._sentryDebugIdIdentifier="sentry-dbid-8dc80c4c-c839-4c5e-b624-d67c4ba75bc0")}catch(e){}}();async function getMod() {
						return import('./natural-language-processing.B9usafMT.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
