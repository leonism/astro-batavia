;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d979a2ae-5a73-4700-9e03-104699a0f7fc",e._sentryDebugIdIdentifier="sentry-dbid-d979a2ae-5a73-4700-9e03-104699a0f7fc")}catch(e){}}();async function getMod() {
						return import('./machine-learning-beginners-guide.CnXf-rfx.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
