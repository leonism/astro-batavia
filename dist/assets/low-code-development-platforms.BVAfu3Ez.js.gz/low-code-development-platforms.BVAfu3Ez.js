;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="45c5751a-b14e-48ff-b629-55e125d3af23",e._sentryDebugIdIdentifier="sentry-dbid-45c5751a-b14e-48ff-b629-55e125d3af23")}catch(e){}}();async function getMod() {
						return import('./low-code-development-platforms.CMU6DvRx.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
