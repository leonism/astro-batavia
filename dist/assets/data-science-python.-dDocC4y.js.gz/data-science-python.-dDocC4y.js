;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="dacbaa3b-d096-44c9-87b5-efe258bd39c2",e._sentryDebugIdIdentifier="sentry-dbid-dacbaa3b-d096-44c9-87b5-efe258bd39c2")}catch(e){}}();async function getMod() {
						return import('./data-science-python.CjcaiYz0.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
