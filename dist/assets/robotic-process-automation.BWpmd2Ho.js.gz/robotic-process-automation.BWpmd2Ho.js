;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="bf5fd849-fcd8-493d-a71e-a888d506fce9",e._sentryDebugIdIdentifier="sentry-dbid-bf5fd849-fcd8-493d-a71e-a888d506fce9")}catch(e){}}();async function getMod() {
						return import('./robotic-process-automation.OUup7D7l.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
