;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="66e8e122-764c-4ca6-90e1-8da4afd40dd8",e._sentryDebugIdIdentifier="sentry-dbid-66e8e122-764c-4ca6-90e1-8da4afd40dd8")}catch(e){}}();async function getMod() {
						return import('./web-development-trends-2024.iYI_H6jv.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
