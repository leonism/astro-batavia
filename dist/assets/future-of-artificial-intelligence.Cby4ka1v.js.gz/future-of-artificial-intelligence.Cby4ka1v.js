;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="1d2b8cd3-b2fa-4789-9879-9dfae4c5f054",e._sentryDebugIdIdentifier="sentry-dbid-1d2b8cd3-b2fa-4789-9879-9dfae4c5f054")}catch(e){}}();async function getMod() {
						return import('./future-of-artificial-intelligence.dfIk37go.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
