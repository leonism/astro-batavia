;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3244b365-cce6-4ccc-9c99-5328cfd7a991",e._sentryDebugIdIdentifier="sentry-dbid-3244b365-cce6-4ccc-9c99-5328cfd7a991")}catch(e){}}();async function getMod() {
						return import('./5g-technology-impact.DmDR5lGg.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
