;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="39cf7c47-042d-4b01-b524-e90d0924c248",e._sentryDebugIdIdentifier="sentry-dbid-39cf7c47-042d-4b01-b524-e90d0924c248")}catch(e){}}();async function getMod() {
						return import('./microservices-architecture.AeVBBkd_.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
