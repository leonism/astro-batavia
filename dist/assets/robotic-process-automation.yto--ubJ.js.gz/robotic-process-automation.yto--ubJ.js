;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3a0e7daa-1e49-4c51-8a18-aab1a9a64ee6",e._sentryDebugIdIdentifier="sentry-dbid-3a0e7daa-1e49-4c51-8a18-aab1a9a64ee6")}catch(e){}}();async function getMod() {
						return import('./robotic-process-automation.r5BUC8zp.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
