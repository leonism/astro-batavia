;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="24a5da76-47d8-4f3b-b9c5-5b50b09ef943",e._sentryDebugIdIdentifier="sentry-dbid-24a5da76-47d8-4f3b-b9c5-5b50b09ef943")}catch(e){}}();async function getMod() {
						return import('./iot-smart-cities.DHYV7wq3.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
