;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="ff0d9538-f2a1-4fa0-a310-57e044a423de",e._sentryDebugIdIdentifier="sentry-dbid-ff0d9538-f2a1-4fa0-a310-57e044a423de")}catch(e){}}();async function getMod() {
						return import('./blockchain-beyond-cryptocurrency.DgGB-SAF.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
