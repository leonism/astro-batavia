;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="381093ff-19f7-445c-84e6-6dff7ef3abb0",e._sentryDebugIdIdentifier="sentry-dbid-381093ff-19f7-445c-84e6-6dff7ef3abb0")}catch(e){}}();async function getMod() {
						return import('./iot-smart-cities.C35jJA7p.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
