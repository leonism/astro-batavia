;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="58eb95aa-9a3e-4c12-bbe5-0a8738479045",e._sentryDebugIdIdentifier="sentry-dbid-58eb95aa-9a3e-4c12-bbe5-0a8738479045")}catch(e){}}();async function getMod() {
						return import('./5g-technology-impact.CiLZqOLG.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
