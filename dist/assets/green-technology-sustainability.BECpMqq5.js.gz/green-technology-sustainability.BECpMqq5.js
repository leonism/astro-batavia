;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="4f5e9cb7-d19a-4064-ad88-7250d1cbb268",e._sentryDebugIdIdentifier="sentry-dbid-4f5e9cb7-d19a-4064-ad88-7250d1cbb268")}catch(e){}}();async function getMod() {
						return import('./green-technology-sustainability.Bz0LBuFS.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
