;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="c42bf412-e1b7-44ae-b32c-fddb9bb6d4ce",e._sentryDebugIdIdentifier="sentry-dbid-c42bf412-e1b7-44ae-b32c-fddb9bb6d4ce")}catch(e){}}();async function getMod() {
						return import('./quantum-computing-basics.B9ExdORv.js');
					}
					const collectedLinks = [];
					const collectedStyles = [];
					const defaultMod = { __astroPropagation: true, getMod, collectedLinks, collectedStyles, collectedScripts: [] };

export { defaultMod as default };
